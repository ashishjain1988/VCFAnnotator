## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  echo = TRUE,
  message = FALSE,
  warning = FALSE,
  fig.width=8, fig.height=5
)

## ----eval=FALSE---------------------------------------------------------------
#  install.packages(c("tidyverse","ensurer","httr","jsonlite"))

## ----eval=FALSE---------------------------------------------------------------
#  install.packages("devtools")
#  library("devtools")
#  install_github("ashishjain1988/VCFAnnotator-Tempus")

## ----eval=FALSE---------------------------------------------------------------
#  install.packages("<Absolute Path>/VCFAnnotatorTempus_1.0.0.tar.gz", repos = NULL)

## ----eval=FALSE---------------------------------------------------------------
#  library(VCFAnnotatorTempus)
#  
#  VCFfilePath <- system.file('extdata', 'Challenge_data.vcf', package = 'VCFAnnotatorTempus')
#  t <- annotateVariant(file = VCFfilePath)
#  write.table(t,"Challenge_data_annotated_variants.txt",sep="\t",quote = F,row.names = F)

